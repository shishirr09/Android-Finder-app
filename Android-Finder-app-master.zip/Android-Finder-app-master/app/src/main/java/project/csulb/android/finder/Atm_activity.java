package project.csulb.android.finder;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Shishir on 3/28/2016.
 */
public class Atm_activity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_layout);
    }
}
